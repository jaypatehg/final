# Changelog
## [1.0.2] 2022-07-24

### Update v1.0.2

- We used the Chakra UI Circular Progress instead of the plugins since they were deprecated. The plugins are still used in previous versions!

## [1.0.1] 2022-05-16

### Update v1.0.1

- The problem with npm install/ building the project was fixed.

### Added dependencies

```
chakra-ui/system                      1.12.1
```

### Updated dependencies

```
chakra-ui/icons                      1.0.14         →         1.1.5
chakra-ui/react                      1.6.5          →         1.8.8
chakra-ui/theme-tools                1.1.9          →         1.3.6
```
## [1.0.0] 2022-01-10

### Original Release

- Added Chakra UI as base framework